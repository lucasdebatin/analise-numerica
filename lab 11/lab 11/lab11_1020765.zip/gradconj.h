#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "matriz.h"

int GradienteConjugado (int n, double** A, double* b, double* x, double tol);
