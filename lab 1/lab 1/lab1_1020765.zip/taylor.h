#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define PI 3.14159265358979323846

double fcos (double x);
double fcos_erro (double x);
double fsqrt (double x);
double fsqrt_erro (double x);